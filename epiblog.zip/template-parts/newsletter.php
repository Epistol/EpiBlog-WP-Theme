<!-- Begin Mailchimp Signup Form -->
<link href="//cdn-images.mailchimp.com/embedcode/horizontal-slim-10_7.css" rel="stylesheet" type="text/css">
<style type="text/css">
    .layer {
        background-color: rgba(255, 114, 84, .8);
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;border-radius: 25px;
        padding-bottom: 1rem;
        padding-top: 1rem;
    }
    #mc_embed_signup input.email {
        background-color: #fafafa;border-radius: 15px;border:0px solid;
    }
	#mc_embed_signup{background:#ff7254; clear:left; width:85%; color:white;-webkit-border-radius: 25px;
        border-radius: 25px; margin-top:5%; margin-bottom:5%;
        margin-left:10%;
        background: url("<?php echo get_template_directory_uri(); ?>/img/plaid.jpg");
    }
	/* Add your own Mailchimp form style overrides in your site stylesheet or in this style block.
	   We recommend moving this block and the preceding CSS link to the HEAD of your HTML file. */
</style>
<style type="text/css">
	#mc-embedded-subscribe-form input[type=checkbox]{display: inline; width: auto;margin-right: 10px;}
	#mergeRow-gdpr {margin-top: 20px;}
	#mergeRow-gdpr fieldset label {font-weight: normal;}
	#mc-embedded-subscribe-form .mc_fieldset{border:none;min-height: 0px;padding-bottom:0px;}
</style>
<div id="mc_embed_signup">
    <div class="layer">
        <form action="https://epistol.us19.list-manage.com/subscribe/post?u=c556c5193afb20c1c472fc26e&amp;id=4ff16937e4" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
            <div id="mc_embed_signup_scroll">
                <label for="mce-EMAIL">Tu veux recevoir un récap hebdo ? </label>
                <input type="email" value="" name="EMAIL" class="email" id="mce-EMAIL" placeholder="email address" required>
                <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                <div style="position: absolute; left: -5000px;" aria-hidden="true"><input type="text" name="b_c556c5193afb20c1c472fc26e_4ff16937e4" tabindex="-1" value=""></div>
                <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
            </div>
        </form>
    </div>

</div>

<!--End mc_embed_signup-->